
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: Text('E2B Dictionary'),),
        body: Container(
          height: Size.infinite.height,
          width:Size.infinite.width ,
          color: Colors.white12,
          margin: EdgeInsets.all(50),
          child: ListView(
            children: [
              Text(("English"),
                style:TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue),),
              TextField(
                decoration: InputDecoration(
                  hintText: 'Enter Text',
                  labelText: 'Enter Text'
                ),
              ),
              SizedBox(height: 50,),

              IconButton(onPressed: (){}, icon: Icon(Icons.wifi_protected_setup_outlined,)),

              Text(("Bangla"),
                style:TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue),),
              TextField(
                decoration: InputDecoration(
                    hintText: 'Translation',
                    labelText: 'Translation'
                ),
              ),








            ],
          ),
        ),
      ),
    );
  }
}

