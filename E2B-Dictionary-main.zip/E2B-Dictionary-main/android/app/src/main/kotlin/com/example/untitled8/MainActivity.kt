package com.example.untitled8

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
